const DEFAULT_CHILDREN = "Save";

export { DEFAULT_CHILDREN };
