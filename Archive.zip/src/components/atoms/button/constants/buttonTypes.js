const PRIMARY = "primary";
const SECONDARY = "secondary";
const LIGHT = "light";
const DARK = "dark";

const BUTTON_TYPES = { PRIMARY, SECONDARY, LIGHT, DARK };
export default BUTTON_TYPES;
