import CategoryTile from "./CategoryTile";

export default CategoryTile;
