import LargeBlogCard from "./LargeBlogCard";

export default LargeBlogCard;
