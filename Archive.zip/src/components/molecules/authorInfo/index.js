import AuthorInfo from "./AuthorInfo";

export default AuthorInfo;
