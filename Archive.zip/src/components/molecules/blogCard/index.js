import BlogCard from "./BlogCard";

export default BlogCard;
