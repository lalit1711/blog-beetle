const TITLE = "";
const NAME = "";
const COVER_URL =
	"https://images.unsplash.com/photo-1556888335-95371827d5fb?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1189&q=80";
const URL = "/404";
const AUTHOR_NAME = "";
const CATEGORY_NAME = "";
const BLOG_CONTENT =
	"It’s rather impossible to know all the APIs by heart. This is where cheat sheets come in! Here are It’s rather impossible to know all theAPIs by heart. It’s rather impossible to know all the APIs by heart.";

const DEFAULT_CATEGORY_INFO = {
	title: TITLE,
	name: NAME,
	coverImageSrc: COVER_URL,
	url: URL,
	authorName: AUTHOR_NAME,
	categoryName: CATEGORY_NAME,
	blogContent: BLOG_CONTENT
};
export default DEFAULT_CATEGORY_INFO;
