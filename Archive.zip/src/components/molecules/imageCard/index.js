import ImageCard from "./ImageCard";

export default ImageCard;
