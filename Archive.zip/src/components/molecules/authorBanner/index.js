import AuthorBanner from "./AuthorBanner";

export default AuthorBanner;
