import BriefCard from "./BriefCard";

export default BriefCard;
