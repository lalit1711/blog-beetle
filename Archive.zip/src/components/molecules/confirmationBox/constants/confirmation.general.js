const PRIMARY_BUTTON = "Save";
const SECONDARY_BUTTON = "Cancel";
const MESSAGE = "Are you sure ?";

export { PRIMARY_BUTTON, SECONDARY_BUTTON, MESSAGE };
