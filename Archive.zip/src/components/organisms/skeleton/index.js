import Skeleton from "./Skeleton";

export default Skeleton;
