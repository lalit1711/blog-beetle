export const IMG_SRC =
	"https://www.winhelponline.com/blog/wp-content/uploads/2017/12/user.png";

export const SOCIAL_LINKS = JSON.stringify({
	facebook: "",
	github: "",
	twitter: "",
	linkedIn: ""
});
