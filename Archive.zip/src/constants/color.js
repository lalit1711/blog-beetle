const RED = "#F55861";
const RED_PINK = "#F5589D";
const PINK = "#F676F0";
const PURPLE = "#C476F6";
const BLUE_1 = "#8276F6";
const BLUE_2 = "#76AEF6";
const LIGHT_BLUE = "#76E0F6";
const GREEN_1 = "#76F6C6";
const GREEN_2 = "#76F692";
const GREEN_3 = "#97F676";
const GREEN_YELLOW = "#CFF676";
const YELLOW = "#F7EB75";
const ORANGE = "#F7AE75";

export default [
	RED,
	RED_PINK,
	PINK,
	PURPLE,
	BLUE_1,
	BLUE_2,
	LIGHT_BLUE,
	GREEN_1,
	GREEN_2,
	GREEN_3,
	GREEN_YELLOW,
	YELLOW,
	ORANGE
];
