import { createContext } from "react";

export const AuthenticatorContext = createContext();
