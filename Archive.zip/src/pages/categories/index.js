import Categories from "./Categories";

export default Categories;
