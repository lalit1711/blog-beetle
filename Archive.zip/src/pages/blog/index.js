import Blog from "./Blog";

export default Blog;
