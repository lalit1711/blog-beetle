import AuthorPage from "./Author";

export default AuthorPage;
