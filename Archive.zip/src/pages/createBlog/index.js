import CreateBlog from "./CreateBlog";

export default CreateBlog;
